# Where these files go

Copy into your `macrotoolkit` repo root, preserving the structure:

```
macrotoolkit/
├── VISION.md                        # from earlier
├── lw-sv-spec.md                    # from earlier
├── scripts/
│   └── gate-check.sh                # chmod +x this
└── .claude/
    ├── settings.json
    └── agents/
        ├── stan-engineer.md
        ├── py-implementer.md
        ├── test-writer.md
        ├── explorer.md              # name field is "Explore" — overrides the built-in
        └── numerics-reviewer.md
```

Then:

```bash
chmod +x scripts/gate-check.sh
```

## Notes

**Create `.claude/agents/` before launching the session.** The file watcher only covers directories that existed when the session started, so a scope's first agent file in a new `agents` directory needs a restart to load.

**`explorer.md` declares `name: Explore`** deliberately. The built-in Explore agent inherits the main conversation's model rather than always running on Haiku; a user or project subagent named `Explore` overrides the built-in and keeps its own model field. Rename it if you'd rather keep the built-in behaviour.

**Check the `sandbox.allowedDomains` list against your actual environment.** Locally, no domains are pre-allowed by default and the first access to a new domain prompts — which an unattended session cannot answer. On Claude Code for the web the proxy allowlist is Anthropic-managed and this setting won't extend it, so pre-commit the HLW fixtures rather than relying on fetching them.

**`scripts/gate-check.sh` reads `.claude/active-gate`** to decide which gate to enforce (a file containing e.g. `G1`). S1 should create it; until then the hook runs the fast suite. Add the file to `.gitignore` if you don't want the active gate tracked.
